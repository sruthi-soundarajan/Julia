Steps to access the documents:
1) First open the .ipynb file to view the project.
2) Please change the file path of csv file inorder to execute the code step by step.
3) Interactive visual boards to pass inputs to the model can be viewed directly in pluto or by installing geogebra app.(Note: There are 3 .ggb file for corresponding models).